%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-10T17:16:38-03:00*%
%TF.ProjectId,openscex-bare,6f70656e-7363-4657-982d-626172652e6b,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-10 17:16:38*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.600000*%
%ADD11R,4.000000X4.000000*%
%ADD12RoundRect,0.250000X-0.550000X0.550000X-0.550000X-0.550000X0.550000X-0.550000X0.550000X0.550000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,C1*%
X122600000Y-113620000D03*
X125100000Y-113620000D03*
%TD*%
D11*
%TO.C,TP2*%
X106810000Y-122370000D03*
%TD*%
D12*
%TO.C,U1*%
X119620000Y-106000000D03*
D10*
X117080000Y-106000000D03*
X114540000Y-106000000D03*
X112000000Y-106000000D03*
X112000000Y-113620000D03*
X114540000Y-113620000D03*
X117080000Y-113620000D03*
X119620000Y-113620000D03*
%TD*%
D11*
%TO.C,TP6*%
X130810000Y-122370000D03*
%TD*%
%TO.C,TP3*%
X112810000Y-122370000D03*
%TD*%
%TO.C,TP4*%
X118810000Y-122370000D03*
%TD*%
%TO.C,TP1*%
X100810000Y-122370000D03*
%TD*%
%TO.C,TP5*%
X124810000Y-122370000D03*
%TD*%
M02*
